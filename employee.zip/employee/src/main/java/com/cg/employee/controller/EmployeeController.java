package com.cg.employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.entity.Employee;
import com.cg.employee.repository.EmployeeRepository;


@RestController

public class EmployeeController {
	
	@Autowired
	private EmployeeRepository repository;
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public Employee create(	@Valid @RequestBody Employee employee)
	{
		return repository.save(employee);
		
	}
	
	@RequestMapping(value="/delete/{emp_id}",method=RequestMethod.DELETE)
	public  void delete(@PathVariable String emp_id)
	{
		
	Employee employee=repository.findOne(emp_id);
	repository.delete(emp_id);	
		
	}
	
	@RequestMapping(value="/read",method=RequestMethod.GET)
	public List<Employee> read()
	{
		return repository.findAll();
		
	}
	@RequestMapping(value="/readById/{empId}",method=RequestMethod.GET)
	public Employee readById(@PathVariable String empId)
	{
		return repository.findOne(empId);
		
	}
	
	
	
	@RequestMapping(value="/update/{empId}",method=RequestMethod.PUT)
	public Employee update(@PathVariable("empId")String  empId,@Valid @RequestBody Employee employee)
	{
		employee.setEmpId(empId);
		repository.save(employee);
		return employee;
	}

	}

