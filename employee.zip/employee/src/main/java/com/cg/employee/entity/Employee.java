package com.cg.employee.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee {

	@Id
	private String empId;
	@NotNull(message = "Employee Name is required")
	@Pattern(regexp = "^[A-Z]{1}[a-z_ ]{2,10}",message="Uppercase,lowercase and whitespace")
	private String empName;
	
	@NotNull(message = "Designation is required")
	@Pattern(regexp = "^[A-Z]{1}[a-z_ ]{2,10}",message="Uppercase,lowercase and whitespace")
	private String designation;
	
	@NotNull(message = "Domain is required")
	@Pattern(regexp = "^[A-Z]{1}[a-z_ ]{2,10}",message="Uppercase,lowercase and whitespace")
	private String domain;
	@NotNull(message = "PAN number is required")
	@Pattern(regexp = "^[A-Z]{4}[0-9]{5,8}",message="Uppercase and digits")
	private String pan;

	@NotEmpty
	@Min(10000)
	private String empSalary;
	@NotNull
	@Pattern(regexp = "^(.+)@(.+)$",message="Enter valid email Id")
	private String mailId;

	@NotNull
	private String password;

	@NotNull
	private Date doj = new Date();

	@NotNull
	
	private Date dob = new Date();

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", designation=" + designation + ", domain=" + domain
				+ ", pan=" + pan + ", empSalary=" + empSalary + ", mailId="
				+ mailId + ", password=" + password + ", doj=" + doj + ", dob="
				+ dob + "]";
	}

	public Employee(String empId, String empName, String designation,
			String domain, String pan, String empSalary, String mailId,
			String password, Date doj, Date dob) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.designation = designation;
		this.domain = domain;
		this.pan = pan;
		this.empSalary = empSalary;
		this.mailId = mailId;
		this.password = password;
		this.doj = doj;
		this.dob = dob;
	}

	public Employee() {
		super();
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

}
